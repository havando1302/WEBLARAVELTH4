<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-baloo mb-6 text-center text-gray-800">Điện thoại giá tốt, đến ngay Dưn </h1>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-lg p-4 hover:shadow-xl transition-shadow">
                    <img src="<?php echo e($product->image_url ? Storage::url($product->image_url) : 'https://via.placeholder.com/300'); ?>" 
                         class="w-full h-48 object-cover rounded-md mb-4" alt="<?php echo e($product->name); ?>">
                    <h3 class="text-lg font-semibold text-gray-800"><?php echo e($product->name); ?></h3>
                    <p class="text-gray-600"><?php echo e(number_format($product->price)); ?> VNĐ</p>
                    <p class="text-sm text-gray-500">Còn <?php echo e($product->stock); ?> sản phẩm</p>
                    <div class="mt-4">
                        <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST" class="mt-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" 
                                        class="bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded w-full">
                                    Thêm vào giỏ hàng
                                </button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="mt-2 bg-gray-500 hover:bg-gray-600 text-black px-4 py-2 rounded w-full text-center block">
                                Đăng nhập để mua hàng
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/index.blade.php ENDPATH**/ ?>