<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-6 text-gray-800">Giỏ hàng của bạn</h1>
        <?php if($cartItems->isEmpty()): ?>
            <p class="text-gray-600">Giỏ hàng của bạn đang trống.</p>
        <?php else: ?>
            <table class="min-w-full bg-white rounded-lg shadow-md border border-gray-200">
                <thead>
                    <tr>
                        <th class="py-3 px-4 border-b text-left text-gray-700 font-semibold">Sản phẩm</th>
                        <th class="py-3 px-4 border-b text-left text-gray-700 font-semibold">Giá</th>
                        <th class="py-3 px-4 border-b text-left text-gray-700 font-semibold">Số lượng</th>
                        <th class="py-3 px-4 border-b text-left text-gray-700 font-semibold">Tổng</th>
                        <th class="py-3 px-4 border-b text-left text-gray-700 font-semibold">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-3 px-4 border-b text-gray-800"><?php echo e($item->product->name); ?></td>
                            <td class="py-3 px-4 border-b text-gray-800"><?php echo e(number_format($item->product->price)); ?> VNĐ</td>
                            <td class="py-3 px-4 border-b text-gray-800"><?php echo e($item->quantity); ?></td>
                            <td class="py-3 px-4 border-b text-gray-800"><?php echo e(number_format($item->product->price * $item->quantity)); ?> VNĐ</td>
                            <td class="py-3 px-4 border-b">
                                <form action="<?php echo e(route('cart.remove', $item->product_id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded" onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                        Xóa
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="mt-6 text-right">
                <p class="text-xl font-bold text-gray-800">Tổng cộng: <?php echo e(number_format($cartItems->sum(function ($item) { return $item->product->price * $item->quantity; }))); ?> VNĐ</p>
                <form action="<?php echo e(route('checkout')); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mt-2">
                        Thanh toán
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/cart.blade.php ENDPATH**/ ?>