<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-6">Thông tin tài khoản</h1>
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
            <p><strong>Tên:</strong> <?php echo e($user->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
            <a href="<?php echo e(route('profile.edit')); ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded mt-4 inline-block">Chỉnh sửa</a>
        </div>
        <form action="<?php echo e(route('profile.destroy')); ?>" method="POST" class="mt-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="bg-red-500 hover:bg-red-600 text-black px-4 py-2 rounded" onclick="return confirm('Bạn có chắc muốn xóa tài khoản?')">Xóa tài khoản</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views\profile\index.blade.php ENDPATH**/ ?>