<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-6">Danh sách đơn hàng</h1>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white dark:bg-gray-800 rounded-lg shadow">
                <thead>
                    <tr class="border-b">
                        <th class="py-2 px-4">ID</th>
                        <th class="py-2 px-4">Khách hàng</th>
                        <th class="py-2 px-4">Tổng tiền</th>
                        <th class="py-2 px-4">Trạng thái</th>
                        <th class="py-2 px-4">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="py-2 px-4"><?php echo e($order->id); ?></td>
                            <td class="py-2 px-4"><?php echo e($order->user->name); ?></td>
                            <td class="py-2 px-4"><?php echo e(number_format($order->total)); ?> VNĐ</td>
                            <td class="py-2 px-4"><?php echo e($order->status); ?></td>
                            <td class="py-2 px-4">
                                <a href="<?php echo e(route('orders.edit', $order)); ?>" class="bg-blue-500 hover:bg-blue-600 text-black px-2 py-1 rounded">
                                    Xem chi tiết
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>