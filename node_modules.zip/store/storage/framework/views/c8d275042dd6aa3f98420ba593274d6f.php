<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold mb-6 text-gray-800">Danh sách sản phẩm</h1>
        <a href="<?php echo e(route('products.create')); ?>" class="bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded mb-4 inline-block">
            + Thêm sản phẩm mới
        </a>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-lg p-4">
                    <img src="<?php echo e($product->image_url ? Storage::url($product->image_url) : 'https://via.placeholder.com/150'); ?>" class="w-full h-40 object-cover rounded-md mb-4" alt="<?php echo e($product->name); ?>">
                    <h3 class="text-lg font-semibold text-gray-800"><?php echo e($product->name); ?></h3>
                    <p class="text-gray-600"><?php echo e(number_format($product->price)); ?> VNĐ</p>
                    <div class="mt-4 flex space-x-2">
                        <a href="<?php echo e(route('products.edit', $product)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-black px-3 py-1 rounded">
                            Sửa
                        </a>
                        <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-600 text-black px-3 py-1 rounded"
                                    onclick="return confirm('Bạn có chắc muốn xóa?')">
                                Xóa
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>