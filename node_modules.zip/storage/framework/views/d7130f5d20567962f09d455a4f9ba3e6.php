

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-bold mb-6">🔔 Thông báo của bạn</h1>

        <?php if($notifications->isEmpty()): ?>
            <div class="text-gray-500">Bạn không có thông báo nào.</div>
        <?php else: ?>
            <div class="space-y-4">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 rounded-lg border shadow-sm <?php echo e($notification->read_at ? 'bg-white' : 'bg-yellow-50'); ?>">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-semibold">
                                    <?php echo e($notification->data['title'] ?? 'Thông báo'); ?>

                                </p>
                                <p class="text-sm text-gray-600">
                                    <?php echo e($notification->data['message'] ?? 'Bạn có thông báo mới.'); ?>

                                </p>
                                <p class="text-xs text-gray-400 mt-1">
                                    <?php echo e($notification->created_at->diffForHumans()); ?>

                                </p>
                            </div>
                            <?php if(is_null($notification->read_at)): ?>
                                <form action="<?php echo e(route('notifications.markAsRead', $notification->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="text-blue-500 text-sm hover:underline">
                                        Đánh dấu đã đọc
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BTLWEB\resources\views/notifications/index.blade.php ENDPATH**/ ?>