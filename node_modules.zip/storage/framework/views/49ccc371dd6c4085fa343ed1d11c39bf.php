

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <div class="bg-white shadow-md rounded-lg p-6">
        <img src="<?php echo e($product->image_url ? asset('storage/' . $product->image_url) : asset('images/default-product.png')); ?>"
             alt="<?php echo e($product->name); ?>"
             class="w-full h-64 object-cover rounded mb-6">
        <h1 class="text-3xl font-bold mb-4"><?php echo e($product->name); ?></h1>
        <p class="text-xl text-green-600 font-semibold mb-2"><?php echo e(number_format($product->price)); ?> VNĐ</p>
        <p class="text-gray-700 mb-6"><?php echo e($product->description); ?></p>
        <a href="<?php echo e(url()->previous()); ?>" class="text-blue-500 hover:underline">← Quay lại</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BTLWEB\resources\views/products/show.blade.php ENDPATH**/ ?>