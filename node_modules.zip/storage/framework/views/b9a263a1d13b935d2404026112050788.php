<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold mb-6 text-gray-800">Sửa sản phẩm</h1>
        <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Tên sản phẩm</label>
                    <input type="text" id="name" name="name" value="<?php echo e($product->name); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Mô tả</label>
                    <textarea id="description" name="description" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required><?php echo e($product->description); ?></textarea>
                </div>
                <div class="mb-4">
                    <label for="price" class="block text-sm font-medium text-gray-700">Giá</label>
                    <input type="number" id="price" name="price" value="<?php echo e($product->price); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" step="0.01" required>
                </div>
                <div class="mb-4">
                    <label for="stock" class="block text-sm font-medium text-gray-700">Số lượng tồn kho</label>
                    <input type="number" id="stock" name="stock" value="<?php echo e($product->stock); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-4">
                    <label for="image_url" class="block text-sm font-medium text-gray-700">Hình ảnh</label>
                    <input type="file" id="image_url" name="image_url" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    <?php if($product->image_url): ?>
                        <img src="<?php echo e(Storage::url($product->image_url)); ?>" class="mt-2 w-32 h-32 object-cover rounded-md" alt="<?php echo e($product->name); ?>">
                    <?php endif; ?>
                </div>
                <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded">
                    Cập nhật sản phẩm
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BTLWEB\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>