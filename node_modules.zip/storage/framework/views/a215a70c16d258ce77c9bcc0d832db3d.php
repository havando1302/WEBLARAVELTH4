

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto py-12 px-6 text-center bg-white shadow-md rounded-lg">
    <h2 class="text-3xl font-bold text-green-600 mb-4">🎉 Thanh toán thành công!</h2>
    <p class="text-gray-700 text-lg mb-6">
        <?php echo e(session('message') ?? 'Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ xử lý đơn hàng sớm nhất.'); ?>

    </p>
    <a href="<?php echo e(route('products.indexPublic')); ?>"
   class="inline-block px-6 py-3 text-black bg-green-500 rounded-md shadow hover:bg-green-600 transition">
    Tiếp tục mua sắm
</a>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BTLWEB\resources\views/checkout/success.blade.php ENDPATH**/ ?>